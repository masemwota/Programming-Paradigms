package value

trait Value {
  
}